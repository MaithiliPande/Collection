package com.yash.myhashset;

import java.util.HashSet;

public class MyHashSetService {
	public static void main(String[] args) {
		HashSet<String> stringSet = new HashSet<String>(5);
		String name="Maithili";
		String dept="Trainee";
		stringSet.add(name);
		stringSet.add(dept);
		System.out.println("String added");
		
		for(String mySet:stringSet)
		{
			System.out.println(mySet);
		}
		

	}
	
	

}
