package com.yash.employee.service;

public interface EmployeeService {
	public void insert();
	public void delete();
	public void update();
	public void search();

}
