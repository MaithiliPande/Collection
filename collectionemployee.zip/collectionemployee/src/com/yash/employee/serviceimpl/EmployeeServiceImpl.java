package com.yash.employee.serviceimpl;

import java.util.ArrayList;

import com.yash.employee.model.Employee;
import com.yash.employee.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService{
	private ArrayList <Employee> empRepository=new  ArrayList<Employee>();
	
	Employee employee;
	
	 EmployeeServiceImpl service;
	public EmployeeServiceImpl(Integer id,String name,String Dept,Integer Salary) {
		new EmployeeServiceImpl(101, "Maithili", "ETC", 1000);
		new EmployeeServiceImpl(102, "Revati", "ET", 1045);
		
	}
	@Override
	public void insert() {
		
		
		
	}
	@Override
	public void delete() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void search() {
		// TODO Auto-generated method stub
		
	}
}
