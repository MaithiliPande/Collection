package com.yash.employee.model;

public class Employee {
	private Integer empId;
	private String empName;
	private String empDepartment;
	private Integer empSalary;
	
	


	public Employee(Integer empId, String empName, String empDepartment, Integer empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empDepartment = empDepartment;
		this.empSalary = empSalary;
	}
	
	public Integer getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public String getEmpDepartment() {
		return empDepartment;
	}
	public Integer getEmpSalary() {
		return empSalary;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setEmpDepartment(String empDepartment) {
		this.empDepartment = empDepartment;
	}
	public void setEmpSalary(Integer empSalary) {
		this.empSalary = empSalary;
	}
	
	

}
