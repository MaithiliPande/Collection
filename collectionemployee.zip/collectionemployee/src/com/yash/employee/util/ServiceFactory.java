package com.yash.employee.util;

import com.yash.employee.model.Employee;
import com.yash.employee.service.EmployeeService;
import com.yash.employee.serviceimpl.EmployeeServiceImpl;

public class ServiceFactory {
	public static EmployeeServiceImpl getEmployeeService()
	{
		return new EmployeeServ();
	}

}
