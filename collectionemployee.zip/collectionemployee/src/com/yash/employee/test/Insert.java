package com.yash.employee.test;



public class Insert {
	public static void main(String[] args) {
		
	}

}
