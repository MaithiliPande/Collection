package collectiondemo;

import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.HashSet;

public class ListDemo {

	public static void main(String[] args) {
		ArrayList<String> names=new ArrayList<String>();
		names.add("Maithili");
	
		
		
		
		

	}

}
