package com.yash.collection.main;

import com.yash.collection.controller.MinionsTCVMController;

public class MinionsTCVMMain {

	public static void main(String[] args) {

		MinionsTCVMController controller = new MinionsTCVMController();
		controller.TCVMOperation();

	}

}
