package com.yash.collection.service;

import java.util.HashMap;

import com.yash.collection.pojo.MinionsTCVM;
import com.yash.collection.util.TCQuantity;

public class BlackCoffeeService {
	int coffeeRequiredQuantity;
	int waterRequiredQuantity;
	int sugarRequiredQuantity;

	int coffeeAvailableQuantity;
	int waterAvailableQuantity;
	int sugarAvailableQuantity;

	static int blackCoffeeCost = 0;

	public int makeBlackCoffee(int noOfCups) {
		TCQuantity tcQuantity = new TCQuantity();
		coffeeRequiredQuantity = (tcQuantity.getIngredientsForBlackCoffee().get("Coffee") * noOfCups);
		waterRequiredQuantity = (tcQuantity.getIngredientsForBlackCoffee().get("Water") * noOfCups);
		sugarRequiredQuantity = (tcQuantity.getIngredientsForBlackCoffee().get("Sugar") * noOfCups);

		coffeeAvailableQuantity = MinionsTCVM.getIngredients().get("Coffee");
		waterAvailableQuantity = MinionsTCVM.getIngredients().get("Water");
		sugarAvailableQuantity = MinionsTCVM.getIngredients().get("Sugar");

		if ((coffeeAvailableQuantity > coffeeRequiredQuantity) && (waterAvailableQuantity > waterRequiredQuantity)
				&& (sugarAvailableQuantity > sugarRequiredQuantity)) {
			HashMap<String, Integer> update = new HashMap<String, Integer>();
			update.put("Coffee", (coffeeAvailableQuantity - coffeeRequiredQuantity));
			update.put("Water", (waterAvailableQuantity - waterRequiredQuantity));
			update.put("Sugar", (sugarAvailableQuantity - sugarRequiredQuantity));
			System.out.println("Black Coffee prepared");
			MinionsTCVM.setIngredients(update);
			blackCoffeeCost = blackCoffeeCost + (noOfCups * 10);
		}

		System.out.println(MinionsTCVM.getIngredients());
		return blackCoffeeCost;
	}

}
