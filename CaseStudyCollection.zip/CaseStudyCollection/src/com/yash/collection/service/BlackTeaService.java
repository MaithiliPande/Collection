//package com.yash.collection.service;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import com.yash.collection.pojo.MinionsTCVM;
//import com.yash.collection.util.TCQuantity;
//
//public class BlackTeaService {
//	int teaRequiredQuantity;
//	int waterRequiredQuantity;
//	int sugarRequiredQuantity;
//	
//	
//	int teaAvailableQuantity,sugarAvailableQuantity,waterAvailableQuantity;
//    static int blackTeaCost=0;
//	public  int makeBlackTea(int noOfCups) {
//		TCQuantity tcQuantity = new TCQuantity();
//		teaRequiredQuantity = (tcQuantity.getIngredientsForBlackTea().get("Tea") * noOfCups);
//		waterRequiredQuantity = (tcQuantity.getIngredientsForBlackTea().get("Water") * noOfCups);
//		sugarRequiredQuantity = (tcQuantity.getIngredientsForBlackTea().get("Sugar") * noOfCups);
//
//		teaAvailableQuantity=MinionsTCVM.getIngredients().get("Tea");
//		waterAvailableQuantity=MinionsTCVM.getIngredients().get("Water");
//		sugarAvailableQuantity=MinionsTCVM.getIngredients().get("Sugar");
//		
//		System.out.println("water: "+waterAvailableQuantity);
//		System.out.println("sugar: "+sugarAvailableQuantity);
//		System.out.println("tea: "+teaAvailableQuantity);
//		
//		
//		if (( teaAvailableQuantity> teaRequiredQuantity)
//				&& ( waterAvailableQuantity> waterRequiredQuantity)
//				&& (sugarAvailableQuantity > sugarRequiredQuantity)) 
//		{
//			
//			
//			HashMap<String, Integer> update = new HashMap<String, Integer>();
//			update.put("Tea", (teaAvailableQuantity- teaRequiredQuantity));
//			update.put("Water", (waterAvailableQuantity- waterRequiredQuantity));
//			update.put("Sugar", (sugarAvailableQuantity- sugarRequiredQuantity));
//			System.out.println("Black tea prepared");
//			MinionsTCVM.setIngredients(update);
//			blackTeaCost=blackTeaCost+(noOfCups*5);
//			
//		}
//
//		System.out.println(MinionsTCVM.getIngredients());
//		return blackTeaCost;
//	}
//
//}
