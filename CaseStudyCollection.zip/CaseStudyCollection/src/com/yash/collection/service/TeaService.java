//package com.yash.collection.service;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import com.yash.collection.pojo.MinionsTCVM;
//import com.yash.collection.util.TCQuantity;
//
//public class TeaService {
//	int teaRequiredQuantity;
//	int waterRequiredQuantity;
//	int sugarRequiredQuantity;
//	int milkRequiredQuantity;
//
//	int teaAvailableQuantity;
//	int waterAvailableQuantity;
//	int sugarAvailableQuantity;
//	int milkAvailableQuantity;
//
//	static int teaCost = 0;
//	TCQuantity tcQuantity;
//
//	public int makeTea(int noOfCups) {
//		tcQuantity = new TCQuantity();
//
//		teaRequiredQuantity = (tcQuantity.getIngredientsForTea().get("Tea") * noOfCups);
//		waterRequiredQuantity = (tcQuantity.getIngredientsForTea().get("Water") * noOfCups);
//		sugarRequiredQuantity = (tcQuantity.getIngredientsForTea().get("Sugar") * noOfCups);
//		milkRequiredQuantity = (tcQuantity.getIngredientsForTea().get("Milk") * noOfCups);
//
//		teaAvailableQuantity = MinionsTCVM.getIngredients().get("Tea");
//		waterAvailableQuantity = MinionsTCVM.getIngredients().get("Water");
//		sugarAvailableQuantity = MinionsTCVM.getIngredients().get("Sugar");
//		milkAvailableQuantity = MinionsTCVM.getIngredients().get("Milk");
//
//		if ((teaAvailableQuantity > teaRequiredQuantity) && (waterAvailableQuantity > waterRequiredQuantity)
//				&& (sugarAvailableQuantity > sugarRequiredQuantity) && (milkAvailableQuantity > milkRequiredQuantity)) {
//
//			HashMap<String, Integer> update = new HashMap<String, Integer>();
//			update.put("Tea", (teaAvailableQuantity - teaRequiredQuantity));
//			update.put("Water", (waterAvailableQuantity - waterRequiredQuantity));
//			update.put("Sugar", (sugarAvailableQuantity - sugarRequiredQuantity));
//			update.put("Milk", (milkAvailableQuantity - milkRequiredQuantity));
//			System.out.println("Tea prepared");
//			MinionsTCVM.setIngredients(update);
//			teaCost = teaCost + (noOfCups * 15);
//		}
//
//		System.out.println(MinionsTCVM.getIngredients());
//		return teaCost;
//	}
//
//}
