package com.yash.collection.util;

import java.util.HashMap;


public class TCQuantity 
{
//	private  HashMap<String, Integer> ingredientsForBlackTea;
//	private  HashMap<String,Integer> ingredientsForTea;
	private  HashMap<String,Integer> ingredientsForCoffee;
	private  HashMap<String, Integer> ingredientsForBlackCoffee;
	
	
	private  HashMap<String, HashMap<String, Integer>>vending;
	
  public TCQuantity() 
  {
	  vending=new HashMap<>();
	  
//	  ingredientsForBlackTea=new HashMap<String,Integer>();
//	  ingredientsForBlackTea.put("Tea",3);
//	  ingredientsForBlackTea.put("Water",100);
//	  ingredientsForBlackTea.put("Sugar",15);
//	  ingredientsForBlackTea.put("Milk",0);
//	  ingredientsForBlackTea.put("Coffee",0);
//	  vending.put("BlackTea", ingredientsForBlackTea);
	  
	  
//	  ingredientsForTea=new HashMap<String,Integer>();
//	  ingredientsForTea.put("Tea", 5);
//	  ingredientsForTea.put("Water", 60);
//	  ingredientsForTea.put("Sugar", 15);
//	  ingredientsForTea.put("Milk", 40);
//	  ingredientsForTea.put("Coffee", 0);
//	  vending.put("Tea", ingredientsForTea);
	  
	  ingredientsForBlackCoffee=new HashMap<String,Integer>();
	  ingredientsForBlackCoffee.put("Tea", 0);
	  ingredientsForBlackCoffee.put("Water", 100);
	  ingredientsForBlackCoffee.put("Sugar", 15);
	  ingredientsForBlackCoffee.put("Milk", 0);
	  ingredientsForBlackCoffee.put("Coffee", 3);
	  vending.put("BlackCoffee", ingredientsForBlackCoffee);
	  
	  ingredientsForCoffee=new HashMap<String,Integer>();
	  ingredientsForCoffee.put("Tea", 0);
	  ingredientsForCoffee.put("Water", 20);
	  ingredientsForCoffee.put("Sugar", 15);
	  ingredientsForCoffee.put("Milk", 80);
	  ingredientsForCoffee.put("Coffee", 4);
	  vending.put("Coffee", ingredientsForCoffee);
	  
  }
  

public  HashMap<String, Integer> getIngredientsForBlackCoffee() {
	return ingredientsForBlackCoffee;
}
//public  HashMap<String, Integer> getIngredientsForBlackTea() {
//	return ingredientsForBlackTea;
//}
public  HashMap<String, Integer> getIngredientsForCoffee() {
	return ingredientsForCoffee;
}
//public  HashMap<String, Integer> getIngredientsForTea() {
//	return ingredientsForTea;
//}
public  HashMap<String, HashMap<String, Integer>> getVending() {
	return vending;
}

}

