package com.yash.collection.pojo;

import java.util.HashMap;

public class MinionsTCVM {
	private static HashMap<String, Integer> ingredients;

	public MinionsTCVM() {
	}

	public static void refillContainers() {
		// fill the containers with their maximum capacity!
		// will be filled just after the starting of vending machine
		ingredients = new HashMap<String, Integer>();
		// ingredients.put("Tea",2000);
		ingredients.put("Milk", 10000);
		ingredients.put("Water", 15000);
		ingredients.put("Coffee", 2000);
		ingredients.put("Sugar", 8000);
	}

	public static HashMap<String, Integer> getIngredients() {
		return ingredients;
	}

	public static void setIngredients(HashMap<String, Integer> ingredients) {
		MinionsTCVM.ingredients = ingredients;
	}

}
