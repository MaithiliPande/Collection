package com.yash.employee.service;

import java.util.List;

import com.yash.employee.model.Employee;

public interface EmployeeService {
	public void insert(Employee employee);
	
	public void deleteById(Integer employeeId);
	
	public void deleteAll(Integer employee);
	
	public Employee getEmployeeById(Integer emId);
	
	public List<Employee> listEmployee();
	
	public void update(Employee updtId);
	
	public List<Employee> sort(int ch);
	
	public List<Employee> noDuplicateEntry();
	
	public void duplicateWithFreq();
}
