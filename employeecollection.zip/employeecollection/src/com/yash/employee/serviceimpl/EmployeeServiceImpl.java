package com.yash.employee.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.yash.employee.model.*;
import com.yash.employee.service.EmployeeService;

import comparator.DepartmentComparator;
import comparator.NameComparator;
import comparator.SalaryComparator;


public class EmployeeServiceImpl implements EmployeeService {
	
	private List<Employee> empRepository = new ArrayList<Employee>();
	Employee employee=new Employee();

	@Override
	public void insert(Employee employee) {
		
		empRepository.add(employee);
		
	}

	@Override
	public  void deleteById(Integer empId) {
		for(Employee emp:empRepository)
		{
			if(emp.getEmpId()==empId)
			{
				System.out.println("id matched");
				empRepository.remove(emp);break;
			}	
		}
	}

	@Override
	public void deleteAll(Integer empl) {
		for(Employee emp:empRepository)
		{
			if(emp.getEmpId()==empl)
			{
				System.out.println("id matched");
				empRepository.remove(emp);
				break;
			}	
		}
		
	}

	@Override
	public Employee getEmployeeById(Integer emplId) {
		for(Employee employee:empRepository)
		{
			if(employee.getEmpId()==emplId)
			{
				return employee;
			}
		}
		return null;
	}

	@Override
	public List<Employee> listEmployee() {
		
		return empRepository;
		
	}

	@Override
	public void update(Employee updateEmployee) {
		for(Employee empl:empRepository)
		{
			if(empl.getEmpId()== updateEmployee.getEmpId())
			{
				empl.setEmpName(updateEmployee.getEmpName());
				empl.setEmpDept(updateEmployee.getEmpDept());
				empl.setEmpSal(updateEmployee.getEmpSal());
			}
		}
	}

	@Override
	public List<Employee> sort(int choice) {
		if(choice == 1)
		{
			Collections.sort(empRepository, new NameComparator());
			return empRepository;
		}
		else if(choice == 2)
		{
			Collections.sort(empRepository, new DepartmentComparator());
			return empRepository;
		}
		else if(choice == 3)
		{
			Collections.sort(empRepository, new SalaryComparator());
			return empRepository;
		}
		return null;
	}

	@Override
	public List<Employee> noDuplicateEntry() {
		List <Employee> duplicate = new ArrayList<Employee>();
		List <Employee> nonDuplicate = new ArrayList<Employee>();
		nonDuplicate.addAll(empRepository);
		for(int i=0; i<nonDuplicate.size();i++)
		{
			for(int j=i+1;j<nonDuplicate.size();j++)
			{
				if(nonDuplicate.get(i).equals(nonDuplicate.get(j)))
				{
					duplicate.add(nonDuplicate.get(i));
					duplicate.add(nonDuplicate.get(j));
				}				
			}			
		}
		nonDuplicate.removeAll(duplicate);
		return nonDuplicate;
	}

	@Override
	public void duplicateWithFreq() {
		int duplicateCount=1;
		List <Employee> tempList = new ArrayList<Employee>();
		for(int i=0; i<empRepository.size();i++)
		{
			duplicateCount=1;
			if(!(tempList.contains(empRepository.get(i))))
			for(int j=i+1;j<empRepository.size();j++)
			{
				if(empRepository.get(i).equals(empRepository.get(j)))
				{
					tempList.add(empRepository.get(j));
					duplicateCount++;
				}		
				
			}
			if(duplicateCount>1)
				System.out.println(empRepository.get(i).getEmpName()+":"+duplicateCount);
		}
	}
}
	
	

	
	


