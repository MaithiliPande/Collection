package com.yash.employee.test;

import com.yash.employee.model.Employee;

import com.yash.employee.serviceimpl.EmployeeServiceImpl;

public class InsertEmployeeTest {

	public static void main(String[] args) {
		EmployeeServiceImpl employeeServiceImpl = new EmployeeServiceImpl();
		Employee employee = new Employee(101,"Maithili","Trainee",4000);
		employeeServiceImpl.insert(employee);
		employeeServiceImpl.listEmployee();
		
		

	}

}
