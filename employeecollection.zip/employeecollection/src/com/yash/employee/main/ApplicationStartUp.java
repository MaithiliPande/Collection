package com.yash.employee.main;

import java.util.List;
import java.util.Scanner;
import com.yash.employee.factory.ServiceFactory;
import com.yash.employee.model.Employee;
import com.yash.employee.service.EmployeeService;


public class ApplicationStartUp {
	public static void main(String[] args) {
		int choice;
		String continueChoice;
		EmployeeService employeeServiceImpl = ServiceFactory.getEmployeeService();
		Employee employee;
		do {
		System.out.println("Enter 1: To insert\n2: To delete by id\n3: To delete all\n4: To List\n5: To search employee\n"
							+ "6: Update list\n7: To sort\n8: To sort non-duplicate enteries\n9: To find the number of duplictae enteries"
							+ "\n0:Exit ");
		Scanner sc=new Scanner(System.in);
		choice= sc.nextInt();
		
			switch(choice)
			{
			case 1: 
				employee = new Employee();
				System.out.println("Enter employee id:");
				int id=sc.nextInt();
				employee.setEmpId(id);
				System.out.println("Enter employee name:");
				String name=sc.next();
				employee.setEmpName(name);
				System.out.println("Enter employee department:");
				String dept=sc.next();
				employee.setEmpDept(dept);
				System.out.println("Enter employee salary:");
				int sal=sc.nextInt();
				employee.setEmpSal(sal);
				employeeServiceImpl.insert(employee);
				
				break;
			case 2:
				System.out.println("Enter employee ID to delete");
				int employeeId=sc.nextInt();
				employeeServiceImpl.deleteById(employeeId);
				break;
			case 3:
				employee = new Employee();
				System.out.println("Enter employee id:");
				int delId=sc.nextInt();
				employee.setEmpId(delId);
				System.out.println("Enter employee name:");
				String delName=sc.next();
				employee.setEmpName(delName);
				System.out.println("Enter employee department:");
				String delDept=sc.next();
				employee.setEmpDept(delDept);
				System.out.println("Enter employee salary:");
				int delSal=sc.nextInt();
				employee.setEmpSal(delSal);
				employeeServiceImpl.deleteById(delId);
				
				break;
			case 4:
				List<Employee> empList=employeeServiceImpl.listEmployee();
				for(Employee emp:empList)
				{
					System.out.println(emp);
				}
				break;
				
			case 5:
				System.out.println("Enter employee id to search:");
				int getEmId=sc.nextInt();
				Employee empl=employeeServiceImpl.getEmployeeById(getEmId);
				System.out.println(empl.toString());
				break;
				
			case 6:
				employee = new Employee();
				System.out.println("Enter employee id to update details");
				int updId=sc.nextInt();
				employee.setEmpId(updId);
				System.out.println("Enter employee name:");
				String updName=sc.next();
				employee.setEmpName(updName);
				System.out.println("Enter employee department:");
				String updDept=sc.next();
				employee.setEmpDept(updDept);
				System.out.println("Enter employee salary:");
				int updSal=sc.nextInt();
				employee.setEmpSal(updSal);
				employeeServiceImpl.update(employee);
				break;
			
			case 7:
				System.out.println("Enter 1: to sort by name\n2: to sort by department\n3: to sort by salary");
				int sortChoice=sc.nextInt();
				List<Employee> sortedList=employeeServiceImpl.sort(sortChoice);
				for (Employee newSortedList : sortedList) {
					System.out.println(newSortedList);	
				}
				
				break;
		
			case 8: 
				List<Employee> noDuplicateList=employeeServiceImpl.noDuplicateEntry();
				for (Employee nonDuplicateLists : noDuplicateList) {
					System.out.println(nonDuplicateLists);	
				}
				break;
			case 9:
				employeeServiceImpl.duplicateWithFreq();
				
				
				break;
				
			case 0:
				sc.close();
				System.exit(0);
				break;
				
			default: System.out.println("Invalid choice");
					break;
			}
		System.out.println("Do you want to continue: (y/n)");
		continueChoice=sc.next();
		
		
		}while(continueChoice.equalsIgnoreCase("y"));
		
	}

}
