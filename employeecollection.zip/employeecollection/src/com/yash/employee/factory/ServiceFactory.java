package com.yash.employee.factory;

import com.yash.employee.service.EmployeeService;
import com.yash.employee.serviceimpl.EmployeeServiceImpl;

public class ServiceFactory {
	public static EmployeeService getEmployeeService()
	{
		return new EmployeeServiceImpl();
	}


}
