package com.yash.employee.model;

public class Employee {
	private Integer empId;
	private String empName;
	private String empDept;
	private Integer empSal;
	
	public Employee()
	{
		
	}
	
	public Employee(Integer empId, String empName, String empDept, Integer empSal) {
		
		this.empId = empId;
		this.empName = empName;
		this.empDept = empDept;
		this.empSal = empSal;
	}



	public Integer getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public String getEmpDept() {
		return empDept;
	}
	public Integer getEmpSal() {
		return empSal;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}
	public void setEmpSal(Integer empSal) {
		this.empSal = empSal;
	}
	
	@Override
	public String toString() {
		return "Id: "+this.getEmpId()+"  Name: "+this.getEmpName()+"  Department: "+this.getEmpDept()+"  Salary: "+this.getEmpSal();
	}
	@Override
	public boolean equals(Object obj) {
		Employee compareObj=(Employee)obj;
		if((this.getEmpName().compareTo(compareObj.getEmpName()))==0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
