package comparator;

import java.util.Comparator;

import com.yash.employee.model.Employee;

public class SalaryComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee emp1, Employee emp2) {
		if(emp1.getEmpSal() > emp2.getEmpSal())
		{
			return 1;
		}
		else if(emp1.getEmpSal() == emp2.getEmpSal())
		{
			return 0;
		}
		else if(emp1.getEmpSal() < emp2.getEmpSal())
		{
			return -1;
		}
		return 0;
	}
	

}
